﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello_World
{
	class Program
	{
		static void Main(string[] args)
		{
			//Announce myself to world
			Console.WriteLine("Hello World");
		}
	}
}
